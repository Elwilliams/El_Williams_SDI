/**
 * Created by EWilliams on 7/9/15 For SDI Section 2*
 */
{
var yearCreated; //declaration
      yearCreated = 2015; //definition
      console.log (yearCreated);

var completed; //declaration
      completed = ("appearsInConsole"); //definition
      console.log (completed);

var itisnot2015 = false; //boolean variable

var itIs2015 = true; //boolean variable

    alert ("IfThisShowsIveGotIt"); //alert

//storage container = value


}