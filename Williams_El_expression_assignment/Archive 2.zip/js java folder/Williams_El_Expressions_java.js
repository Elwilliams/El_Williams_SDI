/**
 * Created by EWilliams on 7/14/15.

//Erica Williams Expressions Assignment
//SDI week 2 assignmnet 7/13/2015
*/

var a = 1;
console.log(a);



